#!/bin/bash
# Exit Gate Offline Installer for Raspberry Pi

set -e

APP_NAME="exit-gate-nodejs"
INSTALL_DIR="/opt/$APP_NAME"
SERVICE_NAME="exit-gate"
USER="pi"

echo "=== Exit Gate Offline Installer ==="
echo "Installing from offline bundle..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Install system packages if available
if [ -f "system-packages.txt" ]; then
    echo "Installing system packages..."
    # Note: This requires internet connection
    # For truly offline installation, these packages need to be pre-installed
    # or downloaded as .deb files
    apt update
    xargs -a system-packages.txt apt install -y
fi

# Install Node.js from bundle
if [ -f "node-v*.tar.xz" ]; then
    echo "Installing Node.js from bundle..."
    NODE_ARCHIVE=$(ls node-v*.tar.xz | head -1)
    tar -xf "$NODE_ARCHIVE" -C /usr/local --strip-components=1
    
    # Verify Node.js installation
    if ! command -v node &> /dev/null; then
        echo "Error: Node.js installation failed"
        exit 1
    fi
    
    echo "Node.js version: $(node --version)"
    echo "NPM version: $(npm --version)"
else
    echo "Warning: Node.js bundle not found, assuming Node.js is already installed"
fi

# Create application directory
echo "Creating application directory..."
mkdir -p "$INSTALL_DIR"
chown "$USER:$USER" "$INSTALL_DIR"

# Copy application files
echo "Copying application files..."
cp -r package.json package-lock.json server.js services routes public "$INSTALL_DIR/"

# Copy environment file
if [ -f ".env.example" ]; then
    cp ".env.example" "$INSTALL_DIR/.env"
fi

# Copy documentation
if [ -f "README.md" ]; then cp "README.md" "$INSTALL_DIR/"; fi
if [ -f "SETUP.md" ]; then cp "SETUP.md" "$INSTALL_DIR/"; fi
if [ -f "IMPLEMENTATION.md" ]; then cp "IMPLEMENTATION.md" "$INSTALL_DIR/"; fi

# Install npm dependencies from cache
echo "Installing npm dependencies from cache..."
cd "$INSTALL_DIR"

# Use local npm cache if available
if [ -d "$SCRIPT_DIR/npm-cache" ]; then
    export NPM_CONFIG_CACHE="$SCRIPT_DIR/npm-cache"
    npm ci --offline --no-audit
else
    echo "Warning: NPM cache not found, installing online..."
    npm ci --no-audit
fi

# Set permissions
chown -R "$USER:$USER" "$INSTALL_DIR"

# Create systemd service
echo "Creating systemd service..."
cat > "/etc/systemd/system/$SERVICE_NAME.service" << 'EOF'
[Unit]
Description=Exit Gate Node.js Application
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/opt/exit-gate-nodejs
ExecStart=/usr/local/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"

echo ""
echo "=== Installation completed successfully! ==="
echo ""
echo "Next steps:"
echo "1. Edit configuration: sudo nano $INSTALL_DIR/.env"
echo "2. Start the service: sudo systemctl start $SERVICE_NAME"
echo "3. Check status: sudo systemctl status $SERVICE_NAME"
echo "4. View logs: sudo journalctl -u $SERVICE_NAME -f"
echo ""
echo "Web interface will be available at: http://localhost:3000"
echo ""

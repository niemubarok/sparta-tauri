# Exit Gate Offline Installation Bundle

This bundle contains everything needed to install the Exit Gate application on a Raspberry Pi without internet connection.

## Contents

- **Application files**: Complete Node.js application
- **NPM dependencies**: All required packages cached locally
- **Node.js binary**: ARM-compatible Node.js runtime
- **Installation scripts**: Automated setup scripts
- **Documentation**: Setup and implementation guides

## Installation on Raspberry Pi

1. Transfer this entire folder to your Raspberry Pi
2. Make the installer executable:
   `ash
   chmod +x install-offline.sh
   `
3. Run the installer as root:
   `ash
   sudo ./install-offline.sh
   `
4. Configure the application:
   `ash
   sudo nano /opt/exit-gate-nodejs/.env
   `
5. Start the service:
   `ash
   sudo systemctl start exit-gate
   `

## Testing on Windows

For development testing on Windows, you can use:
`cmd
install-test-windows.bat
`

## Bundle Information

- Created: 2025-06-29 13:42:31
- Node.js version: v20.11.0
- Platform: Raspberry Pi (ARM)

## Files Included

- package.json
- package-lock.json
- server.js
- .env.example
- services
- routes
- public
- README.md
- SETUP.md
- IMPLEMENTATION.md
- .gitignore

## Support

For issues or questions, refer to the included documentation:
- README.md - Main documentation
- SETUP.md - Setup instructions
- IMPLEMENTATION.md - Technical details

